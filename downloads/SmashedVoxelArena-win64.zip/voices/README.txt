Voices for the kill announcer

Put a recording here for any line and the game plays it instead of the stinger (no rebuild: just restart the game).
Name each file after its line, as .mp3, .ogg or .wav (phone recordings in .m4a need converting first):

  first_blood     double_kill     multi_kill      mega_kill       ultra_kill
  monster_kill    ludicrous_kill  holy_shit       headshot
  killing_spree   rampage         dominating      unstoppable     godlike
  wicked_sick     spree_over

e.g. double_kill.mp3. Any you leave out keep their stinger.
