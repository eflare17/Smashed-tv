Smashed TV - voxel arena test (PC)

Unzip all three files into one folder (SmashedVoxelArena.exe, SmashedVoxelArena.pck, the game data, and
libwebrtc_native.windows.template_release.x86_64.dll, the online play), then run SmashedVoxelArena.exe. Windows may say "Windows protected your PC" (the file isn't signed):
click "More info", then "Run anyway".

Enemies come one at a time (F3 or F5 send in more). Every hit makes them stagger back a little.
Shoot or cut limbs off and they keep coming (one leg: limping, no legs: worm-crawling on the floor). They're tough:
body hits take a while to kill, the head dies once a quarter of the brain is gone (or the head comes off).

Weapons in groups, as in Half-Life: press 1-5 for a group, press it again for the next weapon in it (or the mouse
wheel; Q goes back to the last one; R reloads). The bar at the bottom shows them, and above it what the two mouse
buttons do with the one you hold. Every weapon has its own sounds.
 1 Melee
  Sword         left: slash the way you move the mouse as you click      right: chop down
  Bat           left: swing, knocks them flying     right: hold to charge a home run, let go (on the head: off)
  Sledgehammer  left: move the mouse sideways as you click to swing left or right (knocks them flying across the
                room); still mouse: overhead smash, a crater where it lands     right: ground slam
  Chainsaw      left: hold and sweep the mouse to saw through     right: lunge forward, ripping through
  Spear         left: thrust, skewers everyone in a line     right: throw it (right click again to call it back)
 2 Guns
  Pistol        left: fire (held, it sprays wider)     right: aim in     12 a clip
  Shotgun       left: fire and pump (big holes up close, knocks them down)     right: both barrels: blows a chunk
                out at point blank     6 shells, reloads shell by shell
  Laser cutter  left: hold, a thin beam that cuts clean through where you drag it (drag across: limbs off, cut in
                half)     right: hold to overcharge, then a fat beam through everyone in line     R: vent the heat
 3 Special
  Flamethrower  left: hold to spray fire; it spreads over them and burns them to ash, and they run about burning
                right: lob a fire bomb: a patch of fire on the floor
  Freeze ray    left: hold to freeze them solid     right: ice shard: shatters a frozen one into ice cubes
                (any hit shatters a frozen one; frozen ones thaw after 8 s)
  Harpoon gun   left: harpoon one and drag it to you     right: harpoon an arm, leg or the head and yank it off
  Gravity gun   left: grab a body, a live one or a piece; click again to throw it (it bowls the others over)
                right: holding something, drop it; holding nothing, a black hole that pulls everything in and
                crushes it
 4 Explosives
  Grenade launcher  left: bouncing grenade     right: sticky bomb (sticks to them; R sets them all off)
 5 Vacuum       left: hold to suck up the cubes inside the glowing ball (and cut-off pieces and bodies) into your
                backpack      right held + wheel: make the ball bigger or smaller
  F (or a mouse side button): a quick sword slash with whatever you hold.   E: the vacuum and back (at a chest: open
  it; at a bed: lie down).
Knocked-out cubes, cut-off pieces and bodies stay where they land, and lying bodies and pieces can always be cut up
again; the vacuum takes the lot.

Backpack and chests
  Everything the vacuum sucks up goes in your backpack: meat, bone, brain, rubble, charred bits (burnt by the
  flamethrower). Tab (or I) opens it. Two chests and a cabinet stand against the far wall: walk up to one, look at it
  and press E to open it above your backpack.
    left click: pick a stack up / put it down (on a different thing: swap)
    right click: pick up half / put down one
    shift+click: send a stack straight across, backpack <-> chest
    click outside the boxes: drop what's in your hand on the floor (the vacuum picks it up again)
    Tab, E or Esc: close (walking away closes it too)
  The backpack and the chests are saved: they're still there next time you play. When the backpack is full the vacuum
  stops: empty it into a chest. In co-op the chests are the host's, and you both use them.

The bedroom
  Turn round at the start: the door in the wall behind you (a little to the right) leads to the bedroom; it opens
  as you walk up. Enemies can't come in and won't come for you while you're in there.
  Two beds: P1 (blue) is the host's, P2 (green) your mate's. Look at a bed and press E to lie down (health comes back
  three times as fast); E, WASD or Space to get up.
  At the foot of each bed is that player's chest, with a combination padlock hanging open on it.
    L at a chest: hold its padlock up close. Mouse wheel over a number wheel (or click its top / bottom) turns it.
    Lock it: set the wheels to your code, click the shackle shut. Your code shows for a moment, then the wheels
    spin to hide it. Remember it!
    Open it: E at the locked chest, turn the wheels to the code: it springs open and the chest opens.
    R (padlock open): take it off into your backpack. L at a chest with no padlock hangs yours on.
  The wardrobe opens with E. The mirror really reflects: you can see yourself in it.

Digging (the back yard)
  The second door in the wall behind you (to the left of the bedroom's when you turn round) is the back door to the
  yard. Safe there too. Press 6 for the digging tools (6 again swaps between them).
    Shovel  left: dig a scoop of dirt or clay     right: put a scoop of dirt back from your backpack (fill holes)
    Pick    left: break stone, hard rock and gold ore (the shovel just clangs off them)
  The ground is chunky blocks 3 m deep: grass, dirt, clay, stones, stone, hard rock, gold ore deep down, bedrock.
  Everything you dig up goes in your backpack (dirt, clay, stone, gold nuggets). Sometimes a worm wriggles out of
  the dirt: yours. You can climb into the holes you dig (and fall into deep ones).
  You start with a rusty shovel (small scoops, slow, it slips). The tool bench by the back door makes better ones:
    Good shovel    150 stone + 500 bone       bigger scoops, quicker
    Golden shovel  80 gold nuggets + 500 brain    silly: huge scoops, very quick, even through stone
  Look at the bench and press E. The holes and your shovel are saved. In co-op you dig the same ground together.

Co-op with a mate (2 players, over the internet, no port forwarding)
  F7  host: the top of the screen shows a room code (like K7QD). Tell your mate.
  F8  join: type the room code, Enter. You appear next to the host, in the host's arena.
  F9  leave.
  Both of you fight the host's enemies with any weapons; what one of you does to a body the other sees too.
  Direct instead (same house, or a forwarded port): Shift+F7 hosts on UDP port 24643; the other presses F8 and types
  the host's address (like 192.168.1.20). Windows may ask to let the game through the firewall: say yes.
  If F7 says the room is taken, press F7 again for a new code. The host's PC runs the enemies, so the faster PC
  should host.

Health
  The red bar above the weapons. Enemies' swings, burning ones, your own grenades and fire hurt. It comes back on
  its own after 5 s unhurt. At nothing you're down: on your own you get up after 4 s; in co-op your mate stands next
  to you for 2.5 s to get you up (or you get up on your own after 15 s). Both down at once: the enemies stop
  swinging until one of you is up.

Other controls
  WASD move, mouse look, Shift run, Space jump
  V: top-down view / first person (top-down: aim with the mouse)
  F1 shadows on/off   F2 cube size (1 or 2 sprite pixels a cube; not while in co-op)
  F3 ten more enemies   F4 freeze them   F5 a big wave (40)   F6 they can't die (shoot them to pieces)
  (in co-op only the host can freeze them or make them unkillable; the guest's F3/F5 ask the host for more)
  Esc frees the mouse, click to grab it again; Alt+F4 quits

Top left: frames a second, milliseconds a frame, draw calls, triangles, cubes flying, the weapon out, resources.

The .exe is Godot 4.4.1's own Windows player, unchanged (SHA-256
b493c1d53fb915f7805f360cfe42d1c3126e720dfc234a4b0f2feb99200f9a4b); the game is in the .pck. The .dll is godotengine/webrtc-native 1.1.0
(MIT licence), unchanged.
