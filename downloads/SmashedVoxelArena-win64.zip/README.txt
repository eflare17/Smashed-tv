Smashed TV - voxel arena test (PC)

Unzip everything into one folder (SmashedVoxelArena.exe, SmashedVoxelArena.pck, the game data, and
libwebrtc_native.windows.template_release.x86_64.dll, the online play), then run SmashedVoxelArena.exe. Windows may say "Windows protected your PC" (the file isn't signed):
click "More info", then "Run anyway".

Enemies come in waves, each bigger than the last, new kinds joining as you go (F12 switches to one enemy at a
time and back; F3 or F5 send in more). Every fifth wave THE BUTCHER comes first: a boss twice the size with his
health in a bar at the top. Get close and he raises both fists and slams the floor (get out of the way), every
so often he roars and two swarmers come running, and under half health he gets angrier. He's carvable like
everyone else, just far tougher, and he comes back tougher every fifth wave. Every hit makes them stagger back a little.
Shoot or cut limbs off and they keep coming (one leg: limping, no legs: worm-crawling on the floor). They're tough:
body hits take a while to kill, the head dies once a quarter of the brain is gone (or the head comes off).
Three kinds with moves of their own:
  Charger (red): crouches, then runs straight at you and knocks you flying. Shoot it while it crouches, or step
    aside: it's dazed after, longer if it runs into a pillar. Shoot a leg off and it can't charge.
  Thrower (green): keeps its distance and lobs globs of rot at you. Shoot its right arm off and it has to come
    to you.
  Shield brute (blue): a steel shield in front. Shots clang off it and knock its cubes out; shoot holes through
    it, chip it away (he gets angrier and faster) or go round him.

Weapons in groups, as in Half-Life: press 1-5 for a group, press it again for the next weapon in it (or the mouse
wheel; Q goes back to the last one; R reloads). The bar at the bottom shows them, and above it what the two mouse
buttons do with the one you hold. Every weapon has its own sounds.
 1 Melee
  Sword         left: slash the way you move the mouse as you click      right: chop down
  Bat           left: swing, knocks them flying     right: hold to charge a home run, let go (on the head: off)
  Sledgehammer  left: move the mouse sideways as you click to swing left or right (knocks them flying across the
                room); still mouse: overhead smash, a crater where it lands     right: ground slam
  Chainsaw      left: hold and sweep the mouse to saw through     right: lunge forward, ripping through
  Spear         left: thrust, skewers everyone in a line     right: throw it (right click again to call it back)
 2 Guns
  Pistol        left: fire (held, it sprays wider)     right: aim in     12 a clip
  Shotgun       left: fire and pump (big holes up close, knocks them down)     right: both barrels: blows a chunk
                out at point blank     6 shells, reloads shell by shell
  Laser cutter  left: hold, a thin beam that cuts clean through where you drag it (drag across: limbs off, cut in
                half)     right: hold to overcharge, then a fat beam through everyone in line     R: vent the heat
 3 Special
  Flamethrower  left: hold to spray fire; it spreads over them and burns them to ash, and they run about burning
                right: lob a fire bomb: a patch of fire on the floor
  Freeze ray    left: hold to freeze them solid     right: ice shard: shatters a frozen one into ice cubes
                (any hit shatters a frozen one; frozen ones thaw after 8 s)
  Harpoon gun   left: harpoon one and drag it to you     right: harpoon an arm, leg or the head and yank it off
  Gravity gun   left: grab a body, a live one or a piece; click again to throw it (it bowls the others over)
                right: holding something, drop it; holding nothing, a black hole that pulls everything in and
                crushes it
 4 Explosives
  Grenade launcher  left: bouncing grenade     right: sticky bomb (sticks to them; R sets them all off)
 5 Vacuum       left: hold to suck up the cubes inside the glowing ball (and cut-off pieces and bodies) into your
                backpack      right held + wheel: make the ball bigger or smaller
  F (or a mouse side button): a quick sword slash with whatever you hold.   E: the vacuum and back (at a chest: open
  it; at a bed: lie down).
Knocked-out cubes, cut-off pieces and bodies stay where they land, and lying bodies and pieces can always be cut up
again; the vacuum takes the lot.

Bones hold them together
  Shoot or cut through the bone at an elbow or knee and, if some skin is left, the limb sags and flops about from
  it on a strand of raw flesh, the torn ends ragged with the broken bone sticking out, dripping blood (a leg hanging like that is no leg to stand on). It tears off by itself after a while (sooner the thinner the strip,
  and every hit and step tugs it), and one more shot on it finishes it.

Backpack and chests
  Everything the vacuum sucks up goes in your backpack: meat, bone, brain, rubble, charred bits (burnt by the
  flamethrower). Tab (or I) opens it. Two chests and a cabinet stand against the far wall: walk up to one, look at it
  and press E to open it above your backpack.
    left click: pick a stack up / put it down (on a different thing: swap)
    right click: pick up half / put down one
    shift+click: send a stack straight across, backpack <-> chest
    click outside the boxes: drop what's in your hand on the floor (the vacuum picks it up again)
    Tab, E or Esc: close (walking away closes it too)
  The backpack and the chests are saved: they're still there next time you play. When the backpack is full the vacuum
  stops: empty it into a chest. In co-op the chests are the host's, and you both use them.
  A full backpack: anything that isn't cubes (gold, a padlock, eggs, seeds...) waits and goes in as soon as
  there's room (it's saved), so nothing is lost.

The bedroom
  Turn round at the start: the door in the wall behind you (a little to the right) leads to the bedroom; it opens
  as you walk up. Enemies can't come in and won't come for you while you're in there.
  Two beds: P1 (blue) is the host's, P2 (green) your mate's. Look at a bed and press E to lie down (health comes back
  three times as fast); E, WASD or Space to get up.
  At the foot of each bed is that player's chest, with a combination padlock hanging open on it.
    L at a chest: hold its padlock up close. Mouse wheel over a number wheel (or click its top / bottom) turns it.
    Lock it: set the wheels to your code, click the shackle shut. Your code shows for a moment, then the wheels
    spin to hide it. Remember it!
    Open it: E at the locked chest, turn the wheels to the code: it springs open and the chest opens.
    R (padlock open): take it off into your backpack. L at a chest with no padlock hangs yours on.
  The wardrobe opens with E. The mirror really reflects: you can see yourself in it.

Digging (the back yard)
  The second door in the wall behind you (to the left of the bedroom's when you turn round) is the back door to the
  yard. Safe there too. Press 6 for the digging tools (6 again swaps between them).
    Shovel  left: dig a scoop of dirt or clay     right: put a scoop of dirt back from your backpack (fill holes)
    Pick    left: break stone, hard rock and gold ore (the shovel just clangs off them)
  The ground is chunky blocks 3 m deep: grass, dirt, clay, stones, stone, hard rock, gold ore deep down, bedrock.
  Everything you dig up goes in your backpack (dirt, clay, stone, gold nuggets). Sometimes a worm wriggles out of
  the dirt: yours. You can climb into the holes you dig (and fall into deep ones).
  You start with a rusty shovel (small scoops, slow, it slips). The tool bench by the back door makes better ones:
    Good shovel    150 stone + 500 bone       bigger scoops, quicker
    Golden shovel  80 gold nuggets + 500 brain    silly: huge scoops, very quick, even through stone
  Look at the bench and press E. The holes and your shovel are saved. In co-op you dig the same ground together.

Weapon bench (the back yard, against the wall left of the door)
  Spend your cash (kills, buds, eggs) on upgrades. Look at a rack and press E to buy its next level (three each):
    DAMAGE  every weapon hits harder: bigger holes and cuts ($25, $60, $120)
    CLIPS   bigger pistol clip, shotgun tube and grenade drum: x1.5, x2, x2.5 ($20, $50, $100)
    FUEL    the flamethrower's tank, the laser's heat and the freeze ray's charge last longer ($20, $50, $100)
  They're yours (saved with your backpack); in co-op each player buys their own.

Farming (the back yard)
  Kills pay cash (shown above your health): grunt $1, charger $2, thrower $2, batter $3, brute $5, shield brute $6, THE BUTCHER $40. Spend it at the SEEDS crate by the tool
  bench (E: Northern Lights $10 on the left, Sour Diesel $30 on the right). Then (6 again cycles the tools):
    Hoe            left: hoe a row of three planting spots into the grass, the way you face
    E at hoed ground: plant a seed
    Watering can   hold left: pour on the plants (8 plants a can). E at the WATER tank fills it.
  Watered, a plant grows at full speed for 3 minutes; dry it grows at half speed, droops and shows a water drop;
  dry for 2 minutes it wilts and loses a bud. Northern Lights takes 4 minutes (Sour Diesel 6). Every 8 enemies you
  kill gives every plant a big boost. Ready (buds on top): E harvests the buds; sell them at the green BUYER crate.
  Worm farm: E puts in the worms you dig up and scraps (meat, brain; burnt bits count half). The worms turn scraps
  into worm castings over time: E takes them. E at a growing plant with castings feeds it (up to twice): faster, and
  a bud more each time.
  The farm and your cash are saved. In co-op it's the host's farm: you both plant, water and harvest in it.

Chickens (through the gate in the back yard's right-hand fence)
  A wired-in run with a walk-in coop in the far corner. You start with 2 hens.
    E at the gate: open or shut it. Open, the hens wander out into the yard too (and come back in to eat and lay).
    GRAIN sacks inside the coop door: E buys 10 grain for $5. E at the feeder puts in your grain and worms
      (a worm is worth 3 grain). Hungry hens walk in to eat.
    Hens fed well lay eggs in the nest boxes (fed full about every 2 minutes, half fed half as often, hungry never).
    E at a nest box collects its eggs. Left there, eggs hatch into chicks (faster the better fed the hens are),
      which grow into hens, while the coop has room.
    Eggs: sell them at the BUYER crate ($4 each), or press H to eat one (+20 health).
    Hens drop poo: vacuum it up (5). 20 chicken poo feeds a plant like castings do (E at it), or put it in the worm
      farm (E): worms love it.
    The COOP sign by the door: E upgrades it. 4 chickens / 2 nest boxes to start; $100 + 150 stone: 8 / 4;
      $300 + 400 stone: 16 / 6.
  Run at a hen and she flaps off. The chickens are saved; in co-op they're the host's.

The shredder (against the back yard's far fence)
  Gore is worth something now: shred it into bags of blood and bone fertiliser.
    Throw limbs in the top: carry them out of the arena with the gravity gun (through the back door) and drop or
      launch them in. Or vacuum gore up and press E at the machine to put your backpack's gore in.
    It grinds (blood everywhere) and bags drop out onto a pile: E takes them.
    Blood and bone: E at a growing plant feeds it (like worm castings), E at the worm farm puts it in, or E at the
      chickens' feeder (a bag is 12 feeds).
    Its sign upgrades it: hand-crank mincer (hands, feet, forearms) -> electric shredder ($200 + 300 stone: heads,
      legs) -> industrial woodchipper ($600 + 60 gold: anything, whole bodies). Too big for it and it just sits there.
  Burning: the flamethrower chars skin black; keep the flame on a spot and the charred flesh crumbles to ash, down to
  the bone. Ash is lost, and burnt (charred) gore makes far fewer bags: burning trades loot for fun.

The games room (through the purple-framed GAMES ROOM door in the arena's back wall, left of the bedroom)
  A big TV, a couch, the consoles on the wall (Mega Drive, Super Nintendo, Master System, Game Gear) and a shelf of
  game cases. It plays real console games (an emulator built in).
    E at a console on the wall: it comes down onto the table.
    E at a case on the shelf: it comes off into your hands and opens. E at the console on the table: in it goes and
      the TV comes on (the right console comes down by itself).
    E on the couch: sit down and play. Keys: arrows or WASD the d-pad; J K L are A B C (Mega Drive) / Y B A (Super
      Nintendo); U I O are X Y Z / L X R; Enter start; Tab mode / select. A game pad works too. E gets you up.
    E at the console while it's on: eject (where you were is saved; next time you carry on).
  No games come with it apart from our own little test cartridge. Add your own game files: E at the ADD GAMES plaque
  on the shelf picks them from your PC, or put them in the "games" folder next to SmashedVoxelArena.exe. It takes
  .md .bin .gen .smd (Mega Drive), .sfc .smc (Super Nintendo), .sms (Master System), .gg (Game Gear), or a .zip.
  In co-op: the host's TV shows on your mate's TV, and your mate on the couch is player 2.

Co-op with a mate (2 players, over the internet, no port forwarding)
  Press O (or click ONLINE in the top right corner) to open PLAY ONLINE.
  Host: press HOST A GAME. The room code shows big on screen and is already copied: paste it to your mate (Ctrl+V
    in Discord, a text, anything).
  Join: copy the code your mate sent, press O: it's already in the box. Press JOIN. (Or type it, or press PASTE.)
    Next time the last room you joined is in the box for you.
  You appear next to the host, in the host's arena. LEAVE GAME in the same menu goes back to playing alone.
  Same house, or no internet: the host presses SAME HOUSE? HOST DIRECT; their address shows (and is copied); the
    other types that address in the code box and presses JOIN. Windows may ask to let the game through the
    firewall: say yes.
  The host's PC runs the enemies, so the faster PC should host. F7 still hosts straight away.

Gothica
  She lives in the bedroom and the games room, wandering about. Press E at her: she hops and follows you round the
  house (running to keep up). She won't follow you out into the fight: she waits in the bedroom doorway. E again and
  she stays put. Her chest, hair and skirt move with real physics; Settings > Jiggle sets how much (Off, Natural,
  Bouncy, Out of this world).

Kill announcer
  Kills close together: DOUBLE KILL, MULTI KILL, MEGA KILL, ULTRA KILL, MONSTER KILL, LUDICROUS KILL, HOLY SHIT.
  Kills without going down: KILLING SPREE (5), RAMPAGE (10), DOMINATING (15), UNSTOPPABLE (20), GODLIKE (25),
  WICKED SICK (30). Plus FIRST BLOOD and HEADSHOT. Each pays a cash bonus. Settings > Kill announcer turns it off or
  makes it silent. To give it a voice, put recordings in the "voices" folder (see voices/README.txt there).

The mine (dig mode)
  The roller door marked MINE in the yard wall, between the buyer and the back door: E there and you're down the
  mine, a side-on digging game of its own. Up at the LIFT (top left) E brings you back to the yard.
  Keys: A/D drive (push into rock to drill through it), S drill down, W or Space fly up, E at a building,
  right click (hold) or F launch, Q pick what to launch, R (hold) suck up water with the hose, 1 dynamite,
  2 repair kit, 3 teleport home.
  Your digger is the Mole, with Juicy Jared at the controls: it turns to face the way it's going and tips nose-first
  into the ground to drill down. You start with a propeller to fly back up; the MECHANIC sells bigger blades, then
  boosters, then a mega booster (faster climbing, more fuel).
  In a building's menu click a line or press its number; E or Esc closes.
  The ground is made of pixels (like Sand Miner): every one can be drilled out, sand pours when you dig under it,
  water and lava flow into your tunnels, and loose dirt crumbles. The drill fills the launcher with the dirt, clay and
  sand it digs up: shoot dirt to pile it up, sand to pour it, and clay to stick it to a wall (wall off lava, make a
  ledge, block the cops' drones). Hold R by a pool and the hose sucks the water up; pick Water (Q) and spray it on
  lava: it hisses to stone you can drill through.
  The ship floats in water (S dives). Dig out a big room (or blast one) and its roof may not hold: when it cracks
  and groans, get out from under it before it comes down.
  Fuel burns all the time (more flying and drilling). Run out, or wreck the hull, and the tow truck drags you up:
  the cargo's lost and there's a fee. Land softly: falling far hurts.
  Ore: coal near the top, then copper, silver, gold, opal and diamonds deeper down, rarer and worth more. Sell it
  at the ORE box by the fuel station: fly over it (or park by it) and press E, and the Mole squirts its cargo into
  the box nugget by nugget (prices change each day; one thing's in demand). The TRADER sells dynamite, repair kits
  and teleports; fill up at FUEL; the MECHANIC repairs the hull and sells upgrades (drill, lift, fuel tank, cargo bay,
  hull, lights, launcher: four levels each, and the ship changes look with each).
  The cash is the same cash as the rest of the game.
  Down there: boulders that need a better drill, gas pockets (greenish) that go off when drilled, lava that runs into
  your tunnels and burns, mushroom caves (you trip out: the screen swims, the ship floats, the steering drifts; fool's
  gold crumbles; spore clumps sell), a mushroom cathedral with a giant mushroom, old sewers with rats that chew the
  hull (drive over them fast), a cop bunker (get in and the alarm goes; a drone catches you and you're busted: cargo
  and a fifth of your cash gone; ram them fast to smash them), the rival dealers' tunnels and their crew who ram you
  (ram them back harder), and at the very bottom the rock worm with its diamond hoard. The sewers, the cops and the
  rivals can each be switched off in Settings. A fresh claim at the TRADER gives you brand new ground.

Settings (F10, or click SETTINGS in the top right corner)
  LOW / MEDIUM / HIGH / ULTRA / EXTREME, or change any one thing: render scale, anti-aliasing, shadows, lighting
  effects (Ultra adds global illumination and volumetric fog; Extreme draws at 150% and shrinks it, 8x anti-aliasing,
  the sharpest shadows, every effect at its best, reflections, and keeps twice the gore), the cube size, how many
  cubes, pieces and corpses stay about, Gore (Normal / Ultra / Extreme), frame cap, vsync, full screen, field of view,
  mouse speed, volume. It all changes straight away and is remembered.
  Ultra Gore: wounds keep bleeding, stumps spurt with the heartbeat, cut-off bits drip, blood pools on the floor and
  dries darker, shots spray it onto the walls behind, and a kill right in your face splashes your view. Walk through
  a pool and you leave bloody footprints; legless enemies leave a smear as they crawl; blood runs down bodies from
  their wounds; melee weapons get bloodier with every hit and drip.
  The first time, the game picks a preset from your graphics card. RUN BENCHMARK tries each preset from Extreme down
  in a busy fight with grenades going off (about 5 s each) and recommends the best one that holds 60 frames a second; APPLY RECOMMENDED
  puts it on. Esc stops it. (On your own only, not in co-op.)

Health
  The red bar above the weapons. Enemies' swings, burning ones, your own grenades and fire hurt. It comes back on
  its own after 5 s unhurt. At nothing you're down: on your own you get up after 4 s; in co-op your mate stands next
  to you for 2.5 s to get you up (or you get up on your own after 15 s). Both down at once: the enemies stop
  swinging until one of you is up.

Other controls
  WASD move, mouse look, Shift run, Space jump
  V: top-down view / first person (top-down: aim with the mouse)
  F1 shadows on/off   F2 cube size (1 or 2 sprite pixels a cube; not while in co-op)   F10 settings
  F3 ten more enemies   F4 freeze them   F5 a big wave (40)   F6 they can't die (shoot them to pieces)   F12 waves / one at a time
  (in co-op only the host can freeze them or make them unkillable; the guest's F3/F5 ask the host for more)
  H eats an egg (when you're hurt)
  Esc frees the mouse, click to grab it again; Alt+F4 quits

Top left: frames a second, milliseconds a frame, draw calls, triangles, cubes flying, the weapon out, resources.

The .exe is Godot 4.4.1's own Windows player, unchanged (SHA-256
b493c1d53fb915f7805f360cfe42d1c3126e720dfc234a4b0f2feb99200f9a4b); the game is in the .pck. The .dll is godotengine/webrtc-native 1.1.0
(MIT licence), unchanged.
