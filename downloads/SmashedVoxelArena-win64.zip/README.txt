Smashed TV - voxel arena test (PC)

Unzip both files into one folder (SmashedVoxelArena.exe and SmashedVoxelArena.pck, the game data), then run
SmashedVoxelArena.exe. Windows may say "Windows protected your PC" (the file isn't signed):
click "More info", then "Run anyway".

Enemies come one at a time (F3 or F5 send in more). Every hit makes them stagger back a little.
Shoot or cut limbs off and they keep coming (one leg: limping, no legs: worm-crawling on the floor). They're tough:
body hits take a while to kill, the head dies once a quarter of the brain is gone (or the head comes off).

Weapons: 1-8 on the keyboard, or the mouse wheel; Q goes back to the last one. The bar at the bottom shows them,
and above it what the two mouse buttons do with the one you hold.
  1 Blaster       left: fire (hold)              right: aim in
  2 Shotgun       left: fire                     right: both barrels
  3 Sword         left: slash the way you move the mouse as you click      right: chop down
                  (cuts go exactly where the blade passes: arms, hands, legs at the knee, the head off)
  4 Bat           left: swing, knocks them flying     right: hold to charge a home run, let go to swing
                  (a full charge on the head knocks it clean off)
  5 Sledgehammer  left: overhead smash, a crater where it lands     right: ground slam, knocks everyone near down
  6 Chainsaw      left: hold and sweep the mouse to saw through     right: lunge forward, ripping through
  7 Spear         left: thrust, skewers everyone in a line     right: throw it (right click again, or walk up to it,
                  to call it back)
  8 Vacuum        left: hold to suck up the cubes inside the glowing ball (and cut-off pieces), counted as
                  resources in the top-left text      right held + wheel: make the ball bigger or smaller
  F (or a mouse side button): a quick sword slash with whatever you hold.   E: the vacuum and back.
Knocked-out cubes and cut-off pieces stay where they land until you suck them up.

Other controls
  WASD move, mouse look, Shift run, Space jump
  V: top-down view / first person (top-down: aim with the mouse)
  F1 shadows on/off   F2 cube size (1 or 2 sprite pixels a cube)
  F3 ten more enemies   F4 freeze them   F5 a big wave (40)   F6 can't die (shoot them to pieces)
  Esc frees the mouse, click to grab it again; Alt+F4 quits

Top left: frames a second, milliseconds a frame, draw calls, triangles, cubes flying, the weapon out, resources.

The .exe is Godot 4.4.1's own Windows player, unchanged (SHA-256
b493c1d53fb915f7805f360cfe42d1c3126e720dfc234a4b0f2feb99200f9a4b); the game is in the .pck.
