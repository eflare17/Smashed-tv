Smashed TV - voxel arena test (PC)

Unzip both files into one folder (SmashedVoxelArena.exe and SmashedVoxelArena.pck, the game data), then run
SmashedVoxelArena.exe. Windows may say "Windows protected your PC" (the file isn't signed):
click "More info", then "Run anyway".

Enemies come one at a time, walking slower than before (F3 or F5 send in more).

Every hit makes them stagger back a little (they push through again between hits).
Shoot limbs off and they keep coming (one leg: limping, no legs: worm-crawling on the floor); they're tough: body shots take a long time to kill, a head shot kills once a quarter of the brain is shot away.

Controls
  WASD move, mouse look, Shift run, Space jump
  Left click: blaster (hold)    Right click: shotgun
  F (or a mouse side button): sword slash, with the guns still in your hands; it goes the way you move the mouse
     as you press (sideways, down, diagonal; still mouse: back and forth)
  C: sword chop straight down (top-down view: a low sweep at the legs)
     Cuts go exactly where the blade passes: arms, hands, legs at the knee, the top of the head, the head off.
  E: vacuum gun instead of the guns (E again: guns back)
     A see-through ball shows where it points; mouse wheel makes it bigger or smaller. Hold left click: the cubes
     inside the ball (and cut-off pieces) swirl up the beam into the gun, counted as resources at the bottom of the
     top-left text (blocks, meat, bone, brain). Knocked-out cubes stay where they land until you suck them up.
  V: top-down view / first person (top-down: aim with the mouse)
  F1 shadows on/off   F2 cube size (1 or 2 sprite pixels a cube)
  F3 ten more enemies   F4 freeze them   F5 a big wave (40)   F6 can't die (shoot them to pieces)
  Esc frees the mouse, click to grab it again; Alt+F4 quits

Top left: frames a second, milliseconds a frame, draw calls, triangles, cubes flying, meshing jobs.

The .exe is Godot 4.4.1's own Windows player, unchanged (SHA-256
b493c1d53fb915f7805f360cfe42d1c3126e720dfc234a4b0f2feb99200f9a4b); the game is in the .pck.
