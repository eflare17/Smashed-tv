Smashed TV - voxel arena test (PC)

Run SmashedVoxelArena.exe. Windows may say "Windows protected your PC" (the file isn't signed):
click "More info", then "Run anyway".

Enemies come one at a time (F3 or F5 send in more).

Shoot limbs off and they keep coming (one leg: limping, no legs: crawling); they're tough: body shots take a long time to kill, a head shot kills once a quarter of the brain is shot away.

Controls
  WASD move, mouse look, Shift run, Space jump
  Left click: blaster (hold)    Right click: shotgun
  V: top-down view / first person (top-down: aim with the mouse)
  F1 shadows on/off   F2 cube size (1 or 2 sprite pixels a cube)
  F3 ten more enemies   F4 freeze them   F5 a big wave (40)   F6 can't die (shoot them to pieces)
  Esc frees the mouse, click to grab it again; Alt+F4 quits

Top left: frames a second, milliseconds a frame, draw calls, triangles, cubes flying, meshing jobs.
