Smashed TV - voxel arena test (PC)

Unzip both files into one folder (SmashedVoxelArena.exe and SmashedVoxelArena.pck, the game data), then run
SmashedVoxelArena.exe. Windows may say "Windows protected your PC" (the file isn't signed):
click "More info", then "Run anyway".

Enemies come one at a time (F3 or F5 send in more). Every hit makes them stagger back a little.
Shoot or cut limbs off and they keep coming (one leg: limping, no legs: worm-crawling on the floor). They're tough:
body hits take a while to kill, the head dies once a quarter of the brain is gone (or the head comes off).

Weapons in groups, as in Half-Life: press 1-5 for a group, press it again for the next weapon in it (or the mouse
wheel; Q goes back to the last one; R reloads). The bar at the bottom shows them, and above it what the two mouse
buttons do with the one you hold. Every weapon has its own sounds.
 1 Melee
  Sword         left: slash the way you move the mouse as you click      right: chop down
  Bat           left: swing, knocks them flying     right: hold to charge a home run, let go (on the head: off)
  Sledgehammer  left: move the mouse sideways as you click to swing left or right (knocks them flying across the
                room); still mouse: overhead smash, a crater where it lands     right: ground slam
  Chainsaw      left: hold and sweep the mouse to saw through     right: lunge forward, ripping through
  Spear         left: thrust, skewers everyone in a line     right: throw it (right click again to call it back)
 2 Guns
  Pistol        left: fire (held, it sprays wider)     right: aim in     12 a clip
  Shotgun       left: fire and pump (big holes up close, knocks them down)     right: both barrels: blows a chunk
                out at point blank     6 shells, reloads shell by shell
  Laser cutter  left: hold, a thin beam that cuts clean through where you drag it (drag across: limbs off, cut in
                half)     right: hold to overcharge, then a fat beam through everyone in line     R: vent the heat
 3 Special
  Flamethrower  left: hold to spray fire; it spreads over them and burns them to ash, and they run about burning
                right: lob a fire bomb: a patch of fire on the floor
  Freeze ray    left: hold to freeze them solid     right: ice shard: shatters a frozen one into ice cubes
                (any hit shatters a frozen one; frozen ones thaw after 8 s)
  Harpoon gun   left: harpoon one and drag it to you     right: harpoon an arm, leg or the head and yank it off
  Gravity gun   left: grab a body, a live one or a piece; click again to throw it (it bowls the others over)
                right: holding something, drop it; holding nothing, a black hole that pulls everything in and
                crushes it
 4 Explosives
  Grenade launcher  left: bouncing grenade     right: sticky bomb (sticks to them; R sets them all off)
 5 Vacuum       left: hold to suck up the cubes inside the glowing ball (and cut-off pieces and bodies), counted as
                resources in the top-left text      right held + wheel: make the ball bigger or smaller
  F (or a mouse side button): a quick sword slash with whatever you hold.   E: the vacuum and back.
Knocked-out cubes, cut-off pieces and bodies stay where they land, and lying bodies and pieces can always be cut up
again; the vacuum takes the lot.

Other controls
  WASD move, mouse look, Shift run, Space jump
  V: top-down view / first person (top-down: aim with the mouse)
  F1 shadows on/off   F2 cube size (1 or 2 sprite pixels a cube)
  F3 ten more enemies   F4 freeze them   F5 a big wave (40)   F6 can't die (shoot them to pieces)
  Esc frees the mouse, click to grab it again; Alt+F4 quits

Top left: frames a second, milliseconds a frame, draw calls, triangles, cubes flying, the weapon out, resources.

The .exe is Godot 4.4.1's own Windows player, unchanged (SHA-256
b493c1d53fb915f7805f360cfe42d1c3126e720dfc234a4b0f2feb99200f9a4b); the game is in the .pck.
